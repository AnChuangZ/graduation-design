/* 
    1.搜索地点所在城市与当前城市不一致，需要修改；/已解决
    2.根据用户栈计算路线，当栈中元素多于一个时允许计算路线，更新总里程；
    3.允许用户从栈中更改途径点的顺序
 */

var userPoisStack = [];     //用户旅游途径点存储栈
var userSelectPoisCnt = 0;      //用户目前规划路线的途径点总数
var userSelectMileages = 0;     //用户目前规划路堑的总里程

//确认当前用户位于哪个风景区内
var now_scope_name = "北京故宫博物院";
/* window.onload = function() {
    var geoloation = new BMapGL.Geolocation();
    geoloation.getCurrentPosition(function(results) {
        //var now_point = results.point
        console.log(results.point)
        var now_point = {lng:116.42811913748,lat:39.976428277424}
        $.ajax({
            type: 'POST',
            url: '/currentpos/',
            data: JSON.stringify({'point':[now_point.lng, now_point.lat]}),
            datatype: 'json',
            success: function(result) {
                if (result['status'] == 0) {
                    now_scope_name = result['userNowPos'];
                    print(now_scope_name)
                }
                else {
                    alert("您现在所处的位置不在服务范围内!");
                }
            }
        })
    })
} */

//creat map
var now_city = "北京市";
var map = new BMapGL.Map("map_container");    // 创建Map实例 new BMapGL.Point(116.404, 39.915)
var center_point = 
map.centerAndZoom(now_city, 18);  // 初始化地图,设置中心点坐标和地图级别
map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
map.addControl(new BMapGL.ScaleControl());  // 添加比例尺控件
/* map.setMapStyleV2({
    styleId:"d15a2fbafc77b2a3c489279ea37815c0"
}) */

//获取元素对象
function getItem(id)
{
    return document.getElementById(id);
}
var userIn = getItem("searchText");

/* getItem("searchText").addEventListener("input", function(e) {
    animate_hide_detail();
    //getItem("planningSet_box").style.display = "none";
}) */

getItem("mileage").innerHTML = userSelectMileages;
getItem("numPois").innerHTML = userSelectPoisCnt;

function insertHTML(msg)
{
    var html = "<div class="+"item_box"+" onclick="+"poiClick(event)"+"><div id="+"item_title"+">"+msg+"</div></div>";
    getItem("search_res_panel").innerHTML += html;
}

//中文poi检索
var poi_position
function ch_Search(poi_name, city_name)
{
    map.clearOverlays();
    var localSearch = new BMapGL.LocalSearch(city_name, {
        renderOptions: {
            map: map,
            selectFirstResult: true
            //autoViewport: true
        },
        pageCapacity: 1,
        onSearchComplete: function(results) {
            console.log(results._pois[0])
            let tpoint = results._pois[0].point;
            map.setCenter(tpoint);
            poi_address = results._pois[0]["address"];
            getItem("title").innerText = poi_name;
            getItem("address").innerText = results._pois[0].address;
            poi_position = results._pois[0].point;
        }
    })
    localSearch.search(poi_name);
    //getItem("poiDetail_box").style.display = "block";
    animate_show_detail()
}

var ac = new BMapGL.Autocomplete({
    "input" : "searchText",
    "location" : map
});

//鼠标点击高亮选项卡
ac.addEventListener("onconfirm", function(e){
    //当poi所在城市与当前城市不同时，修改地图
    if(e.item.value["city"] !== now_city) {
        //console.log("different!")
        now_city = e.item.value["city"];
        //console.log(now_city)
        map.setCenter(now_city);
    }
    var poi_name = e.item.value["business"];
    ch_Search(poi_name, now_city);
    this.hide();
});

//展开用户选择列表
var selectedFlag = false;
function showSelected()
{
    getItem("chosen_pois").innerHTML = "";
    for(var i = 0; i < userPoisStack.length; i ++) {
        var html = '<div id="chosen_poi' + i + '" class="chosen_poi">' +
                        '<input class="chosen_poi_name" value="' + userPoisStack[i].title + '" readonly="readonly">' +
                        '<div class="delete_poi_button" onclick="deletePoi(' + i + ')">-</div>' +
                    '</div>'
        if(i) {
            html = '<div class="tripmode_box" onclick="tripModChange(event, ' + i + ')" title="修改出行方式">' +
                        '<img id="tripmodImg' + i + '" class="modeicon" src="/static/png/walk.png">' +
                        '<input id="tripDis' + i + '" class="distanceinfo" type="text" placeholder="距离" value="' + userPoisStack[i].distance + '"readonly="readonly">' +
                        '<input id="tripDura' + i + '" class="timeinfo" type="text" placeholder="预计时间" value="' + userPoisStack[i].duration + '"readonly="readonly">' +
                    '</div>' + html;
            
        }
        getItem("chosen_pois").innerHTML += html;
    }
    if(userSelectPoisCnt && userSelectPoisCnt > 0) {
        getItem("chosen_pois").innerHTML += '<button id="submitPlan_button" type="button" onclick="submitMyPlan()">探索路线</button>'
    }
}
function SelectedUnfold()
{
    if(selectedFlag) {
        selectedFlag = false;
        getItem("unfold_button").innerText = "展开";
        getItem("chosen_pois").innerHTML = ""
    }
    else{
        selectedFlag = true;
        getItem("unfold_button").innerText = "收起";
        getItem("chosen_pois").style.display = "block";
        showSelected();
    }
}

//将当前选择的poi加入用户选择栈
getItem("addToSelect_box").addEventListener("click", function() {
    var this_poi = {};
    //如果有重复的则不添加
    for(var i = 0; i < userPoisStack.length; i ++) {
        if(userPoisStack[i].title === getItem("title").innerText) {
            return;
        }
    }
    this_poi["title"] = getItem("title").innerText;
    this_poi["address"] = getItem("address").innerText;
    this_poi["point"] = poi_position;
    this_poi["tripMod"] = 3;
    this_poi["distance"] = "";
    this_poi["duration"] = "";
    userPoisStack = [...userPoisStack,this_poi];
    getItem("numPois").innerText = ++ userSelectPoisCnt;
    getItem("searchText").value = "";
    animate_hide_detail();
    //console.log(userPoisStack);

    //计算从上一poi以默认通行方式到达当前加入poi的距离
    if (userSelectPoisCnt > 1) {
        var start = userSelectPoisCnt - 2, end = userSelectPoisCnt - 1;
        var transitRoute = new BMapGL.WalkingRoute(map,{
            pageCapacity: 1,
            onSearchComplete: function(results) {
                userPoisStack[end].distance = results.getPlan(0).getDistance();
                userPoisStack[end].duration = results.getPlan(0).getDuration();
            }
        })
        transitRoute.search(userPoisStack[start].point, userPoisStack[end].point);
    }

    if(selectedFlag){
        showSelected();
    }
});

//删除指定poi信息卡
function deletePoi(index)
{
    getItem("numPois").innerText = -- userSelectPoisCnt;
    userPoisStack.splice(index, 1);
    showSelected();
}

//切换出行方式
var now_terminalPoint = -1;
function tripModChange(event, now_index)
{
    now_terminalPoint = now_index;
    var left = getItem("right_panel").offsetLeft - 150;
    var top = event.screenY - 80;
    getItem("tripmodeSelect_box").style.cssText = 'position: absolute; top: ' + top + 'px;' +
    'left: ' + left + 'px;' +
    'width: 150px; height: auto; border-radius: 5px; z-index: 9999; display: block; overflow: hidden;';
}
function myMode(sel)
{
    if (now_terminalPoint > 0) {
        userPoisStack[now_terminalPoint].tripMod = sel;
        var p = ["public", "drive", "ride", "walk"];
        var tmpid = "tripmodImg" + now_terminalPoint;
        getItem(tmpid).src = "/static/png/" + p[sel] + ".png";
        routePlane(sel, now_terminalPoint - 1, now_terminalPoint, true, true);
    }
    getItem("tripmodeSelect_box").style.cssText = "display: none";
}

function routePlane(tripmod, startIndex, perminalIndex, isRender = false, isclear = true)
{
    if (isclear) {
        map.clearOverlays();
    }
    now_terminalPoint = -1;
    switch (tripmod) {
        case 0:    //采用公共交通出行方式
            var transitRoute = new BMapGL.TransitRoute(map,{
                pageCapacity: 1,
                renderOptions: {
                    map: isRender ? map : "",
                },
                onSearchComplete: function(results) {
                    userPoisStack[perminalIndex].distance = results.getPlan(0).getDistance();
                    userPoisStack[perminalIndex].duration = results.getPlan(0).getDuration();
                    getItem("tripDis" + perminalIndex).value = userPoisStack[perminalIndex].distance;
                    getItem("tripDura" + perminalIndex).value = userPoisStack[perminalIndex].duration;
                }
            })
            transitRoute.disableAutoViewport();
            transitRoute.search(userPoisStack[startIndex].point, userPoisStack[perminalIndex].point);
            break;
        case 1:    //采用驾车出行方式
            var driveRoute = new BMapGL.DrivingRoute(map, {
                renderOptions: {
                    map: isRender ? map : "",
                },
                onSearchComplete: function(results) {
                    userPoisStack[perminalIndex].distance = results.getPlan(0).getDistance();
                    userPoisStack[perminalIndex].duration = results.getPlan(0).getDuration();
                    getItem("tripDis" + perminalIndex).value = userPoisStack[perminalIndex].distance;
                    getItem("tripDura" + perminalIndex).value = userPoisStack[perminalIndex].duration;
                }
            })
            driveRoute.disableAutoViewport();
            driveRoute.search(userPoisStack[startIndex].point, userPoisStack[perminalIndex].point);
            break;
        case 2:    //采用骑行出行方式
            var rideRoute = new BMapGL.RidingRoute(map, {
                renderOptions: {
                    map: isRender ? map : "",
                },
                onSearchComplete: function(results) {
                    userPoisStack[perminalIndex].duration = results.getPlan(0).getDuration();
                    userPoisStack[perminalIndex].distance = results.getPlan(0).getDistance();
                    getItem("tripDis" + perminalIndex).value = userPoisStack[perminalIndex].distance;
                    getItem("tripDura" + perminalIndex).value = userPoisStack[perminalIndex].duration;
                }
            })
            rideRoute.disableAutoViewport();
            rideRoute.search(userPoisStack[startIndex].point, userPoisStack[perminalIndex].point);
            break;
        case 3:    //采用步行出行方式
            var walkRoute = new BMapGL.WalkingRoute(map, {
                renderOptions: {
                    map: isRender ? map : "",
                },
                onSearchComplete: function(results) {
                    userPoisStack[perminalIndex].duration = results.getPlan(0).getDuration();
                    userPoisStack[perminalIndex].distance = results.getPlan(0).getDistance();
                    getItem("tripDis" + perminalIndex).value = userPoisStack[perminalIndex].distance;
                    getItem("tripDura" + perminalIndex).value = userPoisStack[perminalIndex].duration;
                }
            })
            walkRoute.disableAutoViewport();
            walkRoute.search(userPoisStack[startIndex].point, userPoisStack[perminalIndex].point);
            break;
        default:
            return;
    }
}

//实时定位
function checkLocation(scale)
{
    var geoloation = new BMapGL.Geolocation();
    geoloation.getCurrentPosition(function(results) {
        if (this.getStatus() == BMAP_STATUS_SUCCESS) {
            switch (scale) {
                case 0:
                    UserViewSector(results.point, now_scope_name);
                    break;
                case 1:
                    UserViewCiecle(results.point, now_scope_name);
                    break;
                default:
                    console.log("UserViewFuntion has something wrong");
            }
        }
    }, 
    function(err){
        console.log("locate has faild");
    },
    {
        enableHighAccuracy: true
    })
}

function submitMyPlan()
{
    map.clearOverlays();
    animate_hide_detail();
    for (var i = 1; i < userSelectPoisCnt; i++) {
        routePlane(userPoisStack[i].tripMod, i - 1, i, true, false);
    }
    //发送ajax请求，查询包含当前用户选择的poi的所有记录中还有那些
    /* $.ajax({
        url: "/datamining/",
        success: function(res) {
            console.log(res);
        }
    }) */
    //开启移步换景
    window.changeStepSce = setInterval("checkLocation(1)",5000)
}

function exitChangeStep()
{
    clearInterval(changeStepSce);
    $('#msgBackground').fadeOut(500);
    map.clearOverlays();
    if (isesplore) {
        isesplore = !isesplore;
        animate_cancle_explore();
    }
}

var isesplore = false;
function explore()
{
    isesplore =  !isesplore;
    if (isesplore) {
        animate_to_explore();
        submitMyPlan();
    }
    else {
        $('#msgBackground').fadeOut(500);
        map.clearOverlays();
        animate_cancle_explore();
    }
}