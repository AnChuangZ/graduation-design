//creat map
var now_city = "北京市";
var map = new BMapGL.Map("map_container");    // 创建Map实例 new BMapGL.Point(116.404, 39.915)‘
map.centerAndZoom(now_city, 18);  // 初始化地图,设置中心点坐标和地图级别
map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
map.addControl(new BMapGL.ScaleControl());  // 添加比例尺控件

var userPoisStack = [];     //用户旅游途径点存储栈
var userSelectPoisCnt = 0;      //用户目前规划路线的途径点总数
var userSelectMileages = 0;     //用户目前规划路堑的总里程

//获取元素对象
function getItem(id)
{
    return document.getElementById(id);
}

//确认当前用户位于哪个风景区内
var now_scope_name = "北京故宫博物院";
/* window.onload = function() {
    var geoloation = new BMapGL.Geolocation();
    geoloation.getCurrentPosition(function(results) {
        var now_point = results.point
        console.log(results.point)
        //var now_point = {lng:116.42811913748,lat:39.976428277424}
        $.ajax({
            type: 'POST',
            url: '/currentpos/',
            data: JSON.stringify({'point':[now_point.lng, now_point.lat]}),
            datatype: 'json',
            success: function(result) {
                if (result['status'] == 0) {
                    now_scope_name = result['userNowPos'];
                    console.log(now_scope_name)
                }
                else {
                    console.log(now_point)
                    alert("您现在所处的位置不在服务范围内!");
                }
            }
        })
    })
} */

//动画
function animate_to_explore_mobile()
{
    var element = getItem("circlebutton");
    var dx = 0;
    var anime = setInterval(function() {
        dx += 2;
        if (dx <= 68) {
            element.style.marginLeft = dx + 'px';
        }
        else {
            element.style.backgroundColor = "#99CCFF"
            element.style.boxShadow = '1px 1px 4px rgb(255, 255, 255);'
            element.innerText = "开";
            clearInterval(anime);
        }
    }, 10)
}
function animate_cancle_explore_mobile()
{
    var element = getItem("circlebutton");
    var dx = 68;
    var anime = setInterval(function() {
        dx -= 2;
        if (dx >= 0) {
            element.style.marginLeft = dx + 'px';
        }
        else {
            element.style.backgroundColor = "#CCCCCC"
            element.style.boxShadow = '1px 1px 4px rgb(255, 255, 255);'
            element.innerText = "关";
            clearInterval(anime);
        }
    }, 10)
}

//实时定位

window.myalpha = 0;
function viewAlpha(opt)
{
    if (typeof(window.myalpha) == 'undefined') {
        window.myalpha = 0;
    }
    if (opt) {
        window.myalpha = (window.myalpha - 1) % 360;
    }
    else {
        window.myalpha = (window.myalpha + 1) % 360;
    }
    checkLocation(0)
}

function checkLocation(scale)
{
    if (typeof(window.myalpha) == 'undefined') {
        window.myalpha = 0;
    }
    var geoloation = new BMapGL.Geolocation();
    geoloation.getCurrentPosition(function(results) {
        if (this.getStatus() == BMAP_STATUS_SUCCESS) {
            switch (scale) {
                case 0:
                    console.log(results.point)
                    UserViewSector(results.point, now_scope_name, window.myalpha);
                    break;
                case 1:
                    UserViewCiecle(results.point, now_scope_name);
                    break;
                default:
                    console.log("UserViewFuntion has something wrong");
            }
        }
    }, 
    function(err){
        console.log("locate has faild");
    },
    {
        enableHighAccuracy: true
    })
}

//开启视角检索
var isesplore = false;
function explore()
{
    isesplore =  !isesplore;
    if (isesplore) {
        animate_to_explore_mobile();
        //window.changeStepSce = setInterval("checkLocation(0)",5000)
        checkLocation(1);
    }
    else {
        //clearInterval(changeStepSce);
        $('#msgBackground').fadeOut(500);
        map.clearOverlays();
        animate_cancle_explore_mobile();
        window.myalpha = 0;
    }
}

//退出视角检索
function exitChangeStep()
{
    //clearInterval(changeStepSce);
    $('#msgBackground').fadeOut(500);
    getItem('msgBox').innerText = '';
    map.clearOverlays();
    if (isesplore) {
        isesplore = !isesplore;
        animate_cancle_explore_mobile();
    }
}

