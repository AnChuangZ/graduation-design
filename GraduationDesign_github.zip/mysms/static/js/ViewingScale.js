function UserViewSector(now_position, now_scope_name, alpha)
{
    var now_lng = 116.404008;
    var now_lat = 39.926863;
    map.clearOverlays();
    var sectorPoints = [];
    var sendSectorPoints = []
    var startradin = (45 - alpha) * Math.PI / 180;
    var endradin = (135 - alpha) * Math.PI / 180;
    var step = (endradin - startradin) / 10;
    for (var i = startradin; i <= endradin; i += step) {
        let lng = now_lng + 0.002 * Math.cos(i);
        let lat = now_lat + 0.002 * Math.sin(i);
        sectorPoints.push(new BMapGL.Point(lng, lat));
        sendSectorPoints.push([lng, lat])
    }
    sectorPoints.push(new BMapGL.Point(now_lng, now_lat));
    var rotaionPolygon = new BMapGL.Polygon(sectorPoints, {strokeColor:"blue", strokeWeight:2, strokeOpacity:0.5})
    map.addOverlay(rotaionPolygon);
    map.setCenter(new BMapGL.Point(now_lng, now_lat));
    //发送ajax计算范围内的poi点
    senddata = {
        'userPosition': [now_lng, now_lat],
        'nowScope': sendSectorPoints,
        'nowParentScope': now_scope_name
    }
    $.ajax({
        type: 'POST',
        url: '/changeStep/',
        data: JSON.stringify(senddata),
        datatype: 'json',
        success: function(result) {
            $('#msgBackground').fadeIn(500);

            //创建当前位置的标注
            let point = new BMapGL.Point(now_lng, now_lat);
            let maker = new BMapGL.Marker(point);
            map.addOverlay(maker);

            //获取结果数据
            data = result['data']['features'];

            //画出每一个在范围内的建筑面
            for (let i = 0; i < result['count']; i++) {
                let polygon = data[i]['geometry']['coordinates'][0];
                let polygon_points = [];
                for (let j = 0; j < polygon.length; j++) {
                    polygon_points.push(new BMapGL.Point(polygon[j][0], polygon[j][1]));
                }
                let draw_polygon = new BMapGL.Polygon(polygon_points, {
                    strokeColor: "blue",
                    fillColor: "#99CCFF",
                    strokeWeight: 1,
                    strokeOpacity: 0.7
                })
                map.addOverlay(draw_polygon);
            }

            //渲染旅游描述文字
            var msg = result['relation_msg']
            var obj = getItem('msgBox')
            obj.innerText = '';
            obj.innerText = msg;
            //animate_show_msg(msgstr);
            var base64 = result['audio'];
            var audioobj = getItem("resAudio");
            audioobj.src = "data:audio/wav;base64," + base64;
            if (audioobj.paused) { //判读是否播放  
                audioobj.paused=false;
                audioobj.play(); //没有就播放 
            }
        }
    })
}


function UserViewCiecle(now_position, now_scope_name) {
    var dx = [-0.001, 0.001, 0.001, -0.001]
    var dy = [-0.001, -0.001, 0.001, 0.001]
    var now_lng = 116.404008;
    var now_lat = 39.926863;
    var point = []
    for (var i = 0; i < 4; i++) {
        point = [...point, [now_lng + dx[i], now_lat + dy[i]]];
    }
    var now_circle = new BMapGL.Circle(new BMapGL.Point(now_lng, now_lat), 120, {
        strokeColor:"blue",
        strokeWeight:2,
        strokeOpacity:0.8,
    })
    map.addOverlay(now_circle)
    map.setCenter(new BMapGL.Point(now_lng, now_lat));

    //注意，此坐标为BD09坐标系，后端接收后需要转换为WGS84坐标系，结果返回同理
    senddata = {
        'userPosition': [now_lng, now_lat],
        'nowScope': [point[0], point[1], point[2], point[3]],
        'nowParentScope': now_scope_name
    }

    $.ajax({
        type: 'POST',
        url: '/changeStep/',
        data: JSON.stringify(senddata),
        datatype: 'json',
        success: function(result) {
            $('#msgBackground').fadeIn(500);

            //创建当前位置的标注;
            var point = new BMapGL.Point(now_lng, now_lat);   
            var marker = new BMapGL.Marker(point); 
            map.addOverlay(marker);

            //获取结果数据
            data = result['data']['features'];
            console.log(data)
            //画出每一个在范围内的建筑面
            for (var i = 0; i < result['count']; i++) {
                var polygon = data[i]['geometry']['coordinates'][0];
                var polygon_points = [];
                for (var j = 0; j < polygon.length; j++) {
                    polygon_points.push(new BMapGL.Point(polygon[j][0], polygon[j][1]));
                }
                var draw_polygon = new BMapGL.Polygon(polygon_points,{
                    strokeColor: "blue",
                    fillColor: "#99CCFF",
                    strokeWeight: 1,
                    strokeOpacity: 0.7
                })
                map.addOverlay(draw_polygon);
            }

            //渲染旅游描述文字
            msg = result['relation_msg']
            obj = getItem('msgBox')
            obj.innerText = '';
            console.log(msg);
            var msgstr = ''
            if (msg.length > 0) {
                for (var i = 0; i < msg.length; i++) {
                    msgstr += msg[i];
                }
                obj.innerText = msgstr;
            }
            else {
                obj.innerText = '前方什么都没有哦~';
            }
        }
    })
}