function getItem(id)
{
    return document.getElementById(id);
}

//点击加入路线时的动画
function animate_show_detail()
{
    var element = getItem('poiDetail_box');
    element.style.display = "block";
    var dheight = 0;
    var anime = setInterval(function(){
        dheight += 5;
        if (dheight <= 400) {
            element.style.height = dheight + 'px';
        }
        else {
            clearInterval(anime);
        }
    }, 5);
}

function animate_hide_detail()
{
    var element = getItem('poiDetail_box');
    var dheight = 400;
    var anime = setInterval(function(){
        dheight -= 5;
        if (dheight >= 0) {
            element.style.height = dheight + 'px';
        }
        else {
            clearInterval(anime);
            element.style.display = "none";
        }
    }, 5);
}

function animate_to_explore()
{
    var element = getItem("circlebutton");
    var dx = 0;
    var anime = setInterval(function() {
        dx += 5;
        if (dx <= 120) {
            element.style.left = dx + 'px';
        }
        else {
            element.style.backgroundColor = "#99CCFF"
            element.innerText = "开";
            clearInterval(anime);
        }
    }, 10)
}
function animate_cancle_explore()
{
    var element = getItem("circlebutton");
    var dx = 120;
    var anime = setInterval(function() {
        dx -= 5;
        if (dx >= 0) {
            element.style.left = dx + 'px';
        }
        else {
            element.style.backgroundColor = "#CCCCCC";
            element.innerText = "关";
            clearInterval(anime);
        }
    }, 10)
}
function animate_show_msg(msgstr)
{
    var element = getItem('msgBox');
    element.innerText = '';
    var strlist = msgstr.split("");
    var idx = 0;
    var length = strlist.length
    var anime = setInterval(function() {
        if (idx < length) {
            element.innerText += strlist[idx];
            idx += 1;
        }
        else {
            clearInterval(anime);
        }
    }, 50)
}