from shapely.geometry import Polygon

#test data
a = Polygon([(0, 0), (2, 1), (3, 3), (1, 2)])
b = Polygon([(4, 4), (5, 4), (5, 5), (4, 5)])

#计算面和面之间的关系
def PolygonCalculate(polygonA, polygonB, scope):
    """ 
    计算polygonA相对于polygonB的位置关系
    """
    #计算polygonA的最小正外接矩形的左下角和右上角坐标
    max_lng = -1e9
    max_lat = -1e9
    min_lng = 1e9
    min_lat = 1e9
    polygonB_points = list(polygonB.exterior.coords[:-1])
    polygonA = Polygon(polygonA.exterior.coords[:-1])

    for xy in polygonB_points:
        if xy[0] > max_lng: 
            max_lng = xy[0]
        if xy[0] < min_lng:
            min_lng = xy[0]
        if xy[1] > max_lat:
            max_lat = xy[1]
        if xy[1] < min_lat:
            min_lat = xy[1]
    minrectangle_NE = (max_lng, max_lat)
    minrectangle_SE = (max_lng, min_lat)
    minrectangle_SW = (min_lng, min_lat)
    minrectangle_NW = (min_lng, max_lat)

    ##可视范围内八个方向的矩形矢量坐标
    polygon_SW = Polygon([scope[0],(min_lng, scope[0][1]), minrectangle_SW, (scope[0][0], min_lat)])
    polygon_S = Polygon([(min_lng, scope[0][1]), (max_lng, max_lat), minrectangle_SE, minrectangle_SW])
    polygon_SE = Polygon([(max_lng, scope[1][1]), scope[1], (scope[1][0], min_lat), minrectangle_SE])
    polygon_E = Polygon([minrectangle_SE, (scope[1][0], min_lat), (scope[1][0], max_lat), minrectangle_NE])
    polygon_NE = Polygon([minrectangle_NE, (scope[2][0], max_lat), scope[2], (max_lng, scope[2][1])])
    polygon_N = Polygon([minrectangle_NW, minrectangle_NE, (max_lng, scope[2][1]), (min_lng, scope[2][1])])
    polygon_NW = Polygon([(scope[3][0], max_lat), minrectangle_NW, (min_lng, scope[3][1]), scope[3]])
    polygon_W = Polygon([(scope[3][0], min_lat), minrectangle_SW, minrectangle_NW, (scope[3][0], max_lng)])

    res_list = ['西南方', '南方', '东南方', '西边', '东北方', '北方', '西北边', '东方']
    cal_list = [polygon_SW, polygon_S, polygon_SE, polygon_E, polygon_NE, polygon_N, polygon_NW, polygon_W]
    max_aera = -1e9
    res_index = -1
    #计算每个方位面与polygonB的相交面积，以最大的为结果
    for i in range(8):
        try:
            if cal_list[i].intersects(polygonA):
                insect_area = cal_list[i].intersection(polygonA).area
                if insect_area > max_aera:
                    max_aera = insect_area
                    res_index = i
        except Exception as es:
            print(es)
    return res_list[res_index]

#计算点和点之间的关系
def PointCalculate(pointA, PointB):
    """
    计算点A相对于点B的位置关系 
    """
    res_list = ['西南方', '南方', '东南方', '西边', '东北方', '北方', '西北边', '东方', '之中']
    dx = pointA[0] - PointB[0]
    dy = pointA[1] - PointB[1]
    if abs(dx) < 0.0001 and abs(dy) < 0.0001:
        return res_list[8]
    elif abs(dx) < 0.0001 and dy > 0.0001:
        return res_list[5]
    elif abs(dx) < 0.0001 and dy < -0.0001:
        return res_list[1]
    elif abs(dy) < 0.0001 and dx > 0.0001:
        return res_list[3]
    elif abs(dy) < 0.0001 and dx < -0.0001:
        return res_list[7]
    elif dx > 0.0001 and dy > 0.0001:
        return res_list[4]
    elif dx > 0.0001 and dy < -0.0001:
        return res_list[2]
    elif dx < -0.0001 and dy < -0.0001:
        return res_list[0]
    else:
        return res_list[6]