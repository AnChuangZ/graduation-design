from django.http import JsonResponse
import json
from LocationConvert import getWgs84xy
import geopandas as gpd
from shapely import geometry, Polygon, Point, to_geojson
from changestep.CoordTransform import wgs84_to_bd09
from changestep.SpatialRelationship import PolygonCalculate, PointCalculate
from changestep.texttospeech import TexttoSpeech
from pymongo import MongoClient
import time

# Create your views here.
def corefunction(request):
    try:
        if request.method == 'POST':
            body = request.body
            data = json.loads(body)
            nowScope = data['nowScope']
            nowParentScope_name = data['nowParentScope']
            wgs84_scope = []

            #将BD09坐标系转换为WGS84坐标系
            for point in nowScope:
                wgs84_scope.append(getWgs84xy(point[0], point[1]))
            userPosition = getWgs84xy(data['userPosition'][0], data['userPosition'][1])

            #print('userPosition:' + userPosition)

            time1 = time.time()

            #读取数据
            """ gdf = gpd.read_file(r"D:\毕设\mysms\beihua.json") """
            myclient = MongoClient('localhost',27017)
            collection = myclient['GeoDB']['detailGeo']
            results = collection.find({"properties.parent":nowParentScope_name}) # 返回的是一个可迭代对象，需要遍历获得具体的值
            gdf = gpd.GeoDataFrame(list(results))
            gdf.drop(columns='_id', axis = 1, inplace = True)
            new_geometry = []
            for idx, row in gdf.iterrows():
                geo = row['geometry']['coordinates'][0]
                geo_polygon = Polygon(geo)
                new_geometry.append(geo_polygon)
            gdf.drop(columns='geometry', axis=1, inplace=True)
            gdf['geometry'] = new_geometry
            #创建当前可视范围

            time2 = time.time()

            now_position_polygon = geometry.Polygon(wgs84_scope)

            #筛选在当前范围内的建筑面
            cnt = 0     #最多10个
            inscope_tags = []  #保存范围内建筑面的名称
            inscope_polygon = []  #保存范围内建筑面的
            now_position_point = []
            res_geojson = {                   #构造返回GeoJSON字符串
                "type": "FeatureCollection",
                "features": [],
            }
            for idx, row in gdf.iterrows():
                if now_position_polygon.intersects(row['geometry']):
                    cnt += 1
                    polygon = row['geometry']#.representative_point()
                    now_position_point.append(row['geometry'].representative_point())

                    tmp = json.loads(to_geojson(row['geometry']))
                    #坐标转换：WGS84->BD09
                    trans_coord = []
                    for xy in tmp['coordinates'][0]:
                        trans_coord.append(wgs84_to_bd09(xy[0], xy[1]))
                    tmp['type'] = tmp['type'].upper()      ##将type改为大写
                    tmp['coordinates'] = [trans_coord]
                    single_geojson = {
                        "type": "Feature",
                        "geometry": tmp
                    }
                    res_geojson['features'].append(single_geojson)
                    inscope_tags.append(row['properties']['name'])
                    inscope_polygon.append(polygon)
                    if cnt >= 15:
                        break
            
            time3 = time.time()

            """ #计算空间关系
            traid = []  ##空间关系三元组
            for i in range(0, cnt - 1):
                for j in range(i + 1, cnt):
                    try:
                        res_rela = PolygonCalculate(inscope_polygon[i], inscope_polygon[j], wgs84_scope)
                    except Exception as es:
                        print("error happeded")
                        print(es)
                        print(inscope_tags[i], inscope_tags[j])
                    traid.append([inscope_tags[i], res_rela, inscope_tags[j]])

            #计算相对用户位置的空间关系
            for i in range(0, cnt):
                print('test test test' + inscope_tags[i])
                print(now_position_point[i].x, now_position_point[i].y)
                res_rela = PointCalculate([now_position_point[i].x, now_position_point[i].y], [userPosition[0], userPosition[1]])
                print(res_rela)
                traid.append(['我', res_rela, inscope_tags[i]]) """

            directionalPattern = {'北方':[], '东北方':[], '东方':[], '东南方':[], '南方':[], '西南方':[], '西边':[], '西北边':[], '之中':[]}
            for i in range(0, cnt):
                res_rela = PointCalculate([now_position_point[i].x, now_position_point[i].y], [userPosition[0], userPosition[1]])
                directionalPattern[res_rela].append({'idx': i, 'geometry': inscope_polygon[i], 'representPoint': now_position_point[i]})

            time4 = time.time()

            mystr = ''
            for key, value in directionalPattern.items():
                length = len(value)
                if length:
                    tmpstr = ''
                    for i in range(length):
                        if i != 0:
                            tmpstr += '在' + inscope_tags[value[i]['idx']] + '的' + PolygonCalculate(value[i]['geometry'], value[i - 1]['geometry'], wgs84_scope) + '是' + inscope_tags[value[i - 1]['idx']]
                        else:
                            tmpstr += '我的' + key + '是' + inscope_tags[value[i]['idx']]
                        if i < length - 1:
                            tmpstr += '，'
                        else:
                            tmpstr += '。'
                    tmpstr += '\n'
                    mystr += tmpstr
            if mystr == '':
                mystr = '前方什么都没有哦！'
            
            time5 = time.time()

            #audio = TexttoSpeech(mystr)

            time6 = time.time()

            print("读取数据:%.6f"%(time2 - time1))
            print("筛选建筑面:%.6f"%(time3 - time2))
            print("点点空间关系计算:%.6f"%(time4 - time3))
            print("面面空间关系计算:%.8f"%(time5 - time4))
            print("文本生成:%.6f"%(time6 - time5))

            #return JsonResponse({'data': res_geojson, 'count': cnt, 'relation_msg': mystr, 'tags': inscope_tags""" , 'audio': audio """})
            return JsonResponse({'data': res_geojson, 'count': cnt, 'relation_msg': mystr, 'tags': inscope_tags})
    except Exception as es:
        print(es)
    #return JsonResponse({'data': res_geojson, 'count': cnt, 'relation_msg': traid, 'tags': inscope_tags})

def currentPosition(request):
    if request.method == 'POST':
        body = request.body
        data = json.loads(body)
        now_point = data['point']
        wgs84_point = getWgs84xy(now_point[0], now_point[1])
        myclient = MongoClient('localhost',27017)
        collection = myclient['GeoDB']['parentGeo']
        results = collection.find() #返回的是一个可迭代对象，需要遍历获得具体的值
        gdf = gpd.GeoDataFrame(list(results))
        gdf.drop(columns='_id', axis = 1, inplace = True)
        for idx, row in gdf.iterrows():
            geo = row['geometry']['coordinates'][0]
            geo_polygon = Polygon(geo)
            if Point(wgs84_point).intersects(geo_polygon):
                print(row['properties']['name'])
                return JsonResponse({"status": 0,"userNowPos": row['properties']['name']})

    return JsonResponse({"status": 1})