from keytotext import pipeline
from time import time

a1 = time()

nlp = pipeline("k2t")

print("\n")
print(nlp(["A", "west","B", "100meter"]))

a2 = time()

print(a2 - a1)